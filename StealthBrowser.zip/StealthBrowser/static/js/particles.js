
class Particle {
    constructor(canvas) {
        this.canvas = canvas;
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.vx = (Math.random() - 0.5) * 2;
        this.vy = (Math.random() - 0.5) * 2;
    }

    update() {
        this.x += this.vx * 1.5;
        this.y += this.vy * 1.5;

        // Wrap around with offset for smoother transition
        const offset = 50;
        if (this.x < -offset) this.x = this.canvas.width + offset;
        if (this.x > this.canvas.width + offset) this.x = -offset;
        if (this.y < -offset) this.y = this.canvas.height + offset;
        if (this.y > this.canvas.height + offset) this.y = -offset;
    }
}

function initParticles() {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.opacity = '0.8';
    canvas.style.zIndex = '-1';
    canvas.style.background = 'url("/attached_assets/delete_forever_24dp_8C1A10_FILL0_wght400_GRAD0_opsz24.png") center/40% no-repeat';
    canvas.style.opacity = '0.65';
    document.body.insertBefore(canvas, document.body.firstChild);

    const ctx = canvas.getContext('2d');
    const particles = [];
    const particleCount = 40;
    const connectionDistance = 100;

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle(canvas));
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'rgba(128, 128, 128, 0.4)';
        ctx.strokeStyle = 'rgba(128, 128, 128, 0.4)';

        particles.forEach(particle => {
            particle.update();
            ctx.beginPath();
            ctx.arc(particle.x, particle.y, 2, 0, Math.PI * 2);
            ctx.fill();

            particles.forEach(otherParticle => {
                const dx = particle.x - otherParticle.x;
                const dy = particle.y - otherParticle.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < connectionDistance) {
                    ctx.beginPath();
                    ctx.moveTo(particle.x, particle.y);
                    ctx.lineTo(otherParticle.x, otherParticle.y);
                    ctx.stroke();
                }
            });
        });

        requestAnimationFrame(animate);
    }

    animate();
}

document.addEventListener('DOMContentLoaded', initParticles);
