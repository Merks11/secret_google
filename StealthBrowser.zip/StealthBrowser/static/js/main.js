document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('redirectForm');
    const urlInput = document.getElementById('urlInput');
    const customTitle = document.getElementById('customTitle');
    const iconPreset = document.getElementById('iconPreset');
    const customIcon = document.getElementById('customIcon');
    const shortcutKey = document.getElementById('shortcutKey');
    const clearShortcut = document.getElementById('clearShortcut');

    // Handle icon preset selection
    iconPreset.addEventListener('change', function() {
        if (this.value === 'custom') {
            customIcon.style.display = 'block';
            customIcon.value = '';
        } else {
            customIcon.style.display = 'none';
            customIcon.value = this.value;
        }
    });

    // Handle keyboard shortcut input
    let currentShortcut = '';
    shortcutKey.addEventListener('keydown', function(e) {
        e.preventDefault();
        currentShortcut = e.key.toUpperCase();
        this.value = currentShortcut;
    });

    clearShortcut.addEventListener('click', function() {
        shortcutKey.value = '';
        currentShortcut = '';
    });

    // Handle global keyboard shortcut
    document.addEventListener('keydown', function(e) {
        if (currentShortcut && e.key.toUpperCase() === currentShortcut) {
            const newWindow = window.open('about:blank', '_blank');
            if (newWindow) {
                newWindow.document.write(`
                    <!DOCTYPE html>
                    <html>
                        <head>
                            <title>Google Classroom</title>
                            <link rel="icon" type="image/x-icon" href="https://google.classroom.com/favicon.ico">
                            <style>
                                body { margin: 0; padding: 0; }
                                iframe { 
                                    position: fixed;
                                    top: 0;
                                    left: 0;
                                    width: 100%;
                                    height: 100%;
                                    border: none;
                                }
                            </style>
                        </head>
                        <body>
                            <iframe src="https://google.classroom.com" allow="fullscreen"></iframe>
                        </body>
                    </html>
                `);
                newWindow.document.close();
            }
        }
    });

    form.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Reset validation state
        form.classList.remove('was-validated');
        urlInput.classList.remove('is-invalid');

        const url = urlInput.value.trim();

        if (!url) {
            form.classList.add('was-validated');
            return;
        }

        try {
            const response = await fetch('/validate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `url=${encodeURIComponent(url)}`
            });

            const data = await response.json();

            if (data.valid) {
                // Create a blank window
                const newWindow = window.open('about:blank', '_blank');

                if (newWindow) {
                    // Get custom settings
                    const pageTitle = customTitle.value.trim() || 'Private Browsing';
                    const faviconUrl = customIcon.value.trim();

                    // Write HTML with hidden iframe to the blank window
                    newWindow.document.write(`
                        <!DOCTYPE html>
                        <html>
                            <head>
                                <title>${pageTitle}</title>
                                ${faviconUrl ? `<link rel="icon" type="image/x-icon" href="${faviconUrl}">` : ''}
                                <style>
                                    body { margin: 0; padding: 0; }
                                    iframe { 
                                        position: fixed;
                                        top: 0;
                                        left: 0;
                                        width: 100%;
                                        height: 100%;
                                        border: none;
                                    }
                                </style>
                            </head>
                            <body>
                                <iframe src="${data.url}" allow="fullscreen"></iframe>
                            </body>
                        </html>
                    `);
                    newWindow.document.close();
                    urlInput.value = ''; // Clear input after successful redirect
                } else {
                    alert('Please allow pop-ups for this site to work properly');
                }
            } else {
                urlInput.classList.add('is-invalid');
                urlInput.setCustomValidity(data.error);
                form.classList.add('was-validated');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        }
    });

    // Clear custom validity on input
    urlInput.addEventListener('input', function() {
        this.setCustomValidity('');
    });
});